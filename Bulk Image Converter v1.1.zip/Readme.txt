Bulk image converter from one extension to another


How to use the software
=========================



1.   Keep all the images to be converted inside one folder so that they can be done in one batch


2.   Create an empty folder. This folder will be used to store the converted images


3.   Load the soft


4.   Click on "Select folder" to load source folder (The folder where all the images to be converted are kept)


5.   Click on "Save to" to set the output location


6.   Select the source image format from the left section in the middle, then click Count button to confirm the number of images to convert based on the "source image format selected"


7.   Select the format to convert to on the right hand side as well. then click on continue.


Just wait for it to complete. You can also check the output folder as the images are being converted.



THANK YOU.